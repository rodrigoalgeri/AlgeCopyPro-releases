AlgeCopy Pro 1.1.1

Pequeno ajuste de experiência para deixar o AlgeCopy Pro ainda mais fluido no dia a dia.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
