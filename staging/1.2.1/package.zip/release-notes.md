AlgeCopy Pro 1.2.1

Mais estabilidade no dia a dia. Aprimoramos a inicialização com o Windows e o acesso ao aplicativo, evitando instâncias duplicadas. Ajustamos a apresentação das configurações e as mensagens de atualização para facilitar a identificação de falhas. Seu histórico, fixados, grupos e preferências continuam preservados.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
