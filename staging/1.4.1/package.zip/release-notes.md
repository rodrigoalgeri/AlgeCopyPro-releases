AlgeCopy Pro 1.4.1

Cor certa, no clique certo. Os textos dos destaques e do tema selecionado ficam brancos, com ajuste de contraste para manter a leitura em qualquer cor escolhida. O seletor de cores da tela agora coleta a cor com um clique do botão esquerdo sobre o ponto desejado. Esc ou botão direito cancelam a seleção. Ajustes disponíveis no painel principal e na janela flutuante.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
