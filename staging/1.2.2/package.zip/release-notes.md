AlgeCopy Pro 1.2.2

Mais fluidez e controle no seu dia a dia. Ajustamos a abertura do painel nas bordas da tela e ampliamos a navegação Vim entre Recentes e Fixados. Conteúdos completos agora podem ser colados somente como texto, mantendo o original para reutilização. Esta versão também inclui a proteção contra instâncias duplicadas e as melhorias de inicialização.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
