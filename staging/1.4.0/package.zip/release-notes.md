AlgeCopy Pro 1.4.0

Seu AlgeCopy, suas cores. Personalize sua área de transferência com os novos temas ChatGPT e VS Code, cada um em modo claro, escuro ou seguindo o Windows. Escolha a cor de destaque entre 12 opções, use o seletor personalizado ou informe um código HEX. Sua escolha acompanha o painel principal e a janela flutuante, fica salva ao reiniciar e pode voltar à cor original do tema com um clique. Os destaques azuis mantêm texto branco para uma leitura mais clara.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
