AlgeCopy Pro 1.10.0

Novo motor Liquid Glass em WebGL2/GLSL, integrado ao Rust/Tauri e à captura nativa do Windows. Refração nas bordas arredondadas, blur adaptativo, dispersão cromática sutil e iluminação com movimento de mola. Modos claro e escuro, ajustes ao vivo e fallback nativo quando a GPU ou a captura não estão disponíveis. A abertura espera o primeiro quadro válido e o renderizador suspende trabalho quando o painel está fechado. A lógica do histórico e da área de transferência foi preservada.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
