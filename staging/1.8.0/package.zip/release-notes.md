AlgeCopy Pro 1.8.0

Reformulação visual do Liquid Glass com referência na Central de Controle do iPhone: painel fumê, textos e ícones brancos em todos os modos, navegação com controles circulares e cartões com cantos mais arredondados. Ajusta a luminosidade do fundo no renderizador nativo para preservar a leitura sobre janelas claras. Transparência, desfoque, refração, saturação e reflexos continuam configuráveis ao vivo, com os acabamentos Cristal, Equilibrado e Fumê. A tela de ajustes passa a usar o próprio painel como prévia. Os outros temas mantêm suas cores. É uma implementação para Windows inspirada nas referências visuais da Apple.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
