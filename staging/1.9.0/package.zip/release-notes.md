AlgeCopy Pro 1.9.0

O Liquid Glass passa a preservar as cores e a luminosidade do conteúdo atrás da janela. O acabamento usa vidro neutro, reflexos nas bordas e textos e ícones brancos com sombra local. A refração agora acompanha também os cartões e controles visíveis, inclusive durante a rolagem. Os ajustes de transparência, desfoque, refração, saturação e reflexos continuam ao vivo. Inclui os acabamentos Cristal, Equilibrado e Fosco. O material foi conferido no aplicativo nativo sobre fundos colorido e claro, com comparação da refração ligada e desligada.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
