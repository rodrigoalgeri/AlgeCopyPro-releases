# AlgeCopy Pro 1.2.0

## Conteúdo completo para reutilizar

Seus modelos agora levam a formatação junto. Guarde uma seleção com texto, links e imagens em uma única entrada e reutilize quando precisar.

- **Cópias completas:** preservação de HTML e RTF, incluindo negrito, itálico, cores, links e imagens incorporadas quando oferecidos pelo programa de origem.
- **Modelos sempre à mão:** fixe, nomeie e organize o conteúdo completo em grupos e categorias. Ele continua salvo ao reabrir o aplicativo.
- **Abra do seu jeito:** somente barrinha, somente cantos ou os dois. Abertura pelos cantos de 0 a 3.000 ms, com opção instantânea.
- **Grupos sem repetição:** os itens organizados aparecem apenas no grupo escolhido. Todos reúne os fixados sem grupo.

Para experimentar, copie novamente a seleção original e cole em um editor que aceite formatação. Campos simples recebem texto; imagens externas dependem da disponibilidade do endereço original. Os itens antigos salvos apenas como texto precisam ser copiados novamente para incluir a formatação.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
