AlgeCopy Pro 1.7.1

Correção do Liquid Glass da versão 1.7.0: substitui o backdrop retangular por um renderizador nativo com Direct2D/DirectComposition, aplica o desfoque ao conteúdo atrás do painel e adiciona controle de refração nas bordas. Corrige a moldura e alinha o recorte dos cantos. Os acabamentos Cristal, Equilibrado e Fumê passam a controlar o novo material. Se o renderizador não estiver disponível, o aplicativo informa o uso de blur nativo sem refração. O blur e a remoção da moldura foram conferidos em uma instância nativa; a comparação visual completa da refração não foi concluída. O resultado não é uma reprodução idêntica do material do macOS.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
