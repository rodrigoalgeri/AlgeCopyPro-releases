AlgeCopy Pro 1.1.0

Seu histórico no ritmo do teclado: chegou o Modo Vim. Ative em Configurações → Comportamento e navegue nos dois painéis com j/k (itens), h/l (grupos dos Fixados), gg/G (primeiro/último), / (pesquisa), Enter (colar), Esc (sair da busca/fechar) e ? (ajuda). Desativado por padrão. A digitação normal na pesquisa e nas edições é preservada; o indicador Vim · ? abre a ajuda. Seus históricos, grupos, categorias e preferências continuam salvos.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
