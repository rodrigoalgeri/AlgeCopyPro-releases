AlgeCopy Pro 1.7.0

Novo tema Liquid Glass em Configurações > Aparência, com acabamentos Cristal, Equilibrado e Fumê. Personalize transparência, desfoque das superfícies, saturação e reflexos, com prévia ao vivo e salvamento automático. O tema acompanha os modos claro, escuro e sistema e sincroniza o painel principal com a janela flutuante. Nas versões compatíveis do Windows, usa o material Acrylic para deixar o fundo da área de trabalho aparecer. Inclui opções para reduzir transparência e desligar reflexos em movimento, respeitando a acessibilidade do sistema. O acabamento é inspirado no Liquid Glass; o material e a refração nativos da Apple não são reproduzidos de forma idêntica.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
