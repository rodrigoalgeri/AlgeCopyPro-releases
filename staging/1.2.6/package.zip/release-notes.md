AlgeCopy Pro 1.2.6

Contorno com mais destaque. A borda da janela principal e da flutuante ficou um pouco mais visível e acompanha as cores do tema, mantendo os cantos arredondados.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
