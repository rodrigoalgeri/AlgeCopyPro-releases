AlgeCopy Pro 1.2.4

Cole do seu jeito. A janela flutuante agora oferece um botão de colar somente texto no canto superior direito de cada item, em Recentes e Fixados. A opção também está disponível no menu dos fixados do painel principal. O conteúdo completo permanece salvo para reutilizar com a formatação original.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
