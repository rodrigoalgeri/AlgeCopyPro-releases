AlgeCopy Pro 1.2.5

Mais destaque, o mesmo jeito de usar. O painel principal e a janela flutuante agora têm um contorno fino que acompanha as cores do tema, para facilitar a identificação das janelas sobre outros aplicativos. O ajuste preserva os cantos arredondados e funciona nos layouts vertical e horizontal.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
