AlgeCopy Pro 1.1.2

Navegue pelos Fixados com ← e →, percorra todos os grupos e retome exatamente de onde parou.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
