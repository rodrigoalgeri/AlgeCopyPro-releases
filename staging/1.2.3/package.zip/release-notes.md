AlgeCopy Pro 1.2.3

Conheça a evolução do AlgeCopy Pro. O novo botão Histórico de versões, em Configurações → Sobre, reúne as novidades e os ajustes de cada lançamento em uma janela própria. A versão instalada fica em destaque, e as descrições podem ser consultadas mesmo sem internet. Novos lançamentos são buscados ao abrir o histórico.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
