AlgeCopy Pro 1.5.0

Novo Colar em sequência no painel principal: selecione até 50 itens, ajuste a ordem e envie um item por vez com Colar próximo. Textos, conteúdo formatado, imagens e arquivos usam a colagem nativa existente. A fila fica apenas nesta sessão; se a colagem falhar, o item permanece para tentar novamente. Inclui backup portátil para exportar e restaurar histórico, grupos, preferências e anexos. Senhas copiadas pelo gerador deixam de entrar no histórico do AlgeCopy.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
