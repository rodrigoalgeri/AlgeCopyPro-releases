AlgeCopy Pro 1.6.0

Colar em sequência ficou mais rápido: depois de iniciar a fila, posicione o cursor no destino e pressione e solte Ctrl + Alt + Shift + V para colar o próximo item, sem reabrir o painel. Um indicador discreto mostra a posição na fila e uma prévia do próximo conteúdo, sem tirar o foco do programa de destino. O atalho fica ativo somente durante a sequência e é liberado ao terminar, cancelar ou editar a fila. Se a combinação já estiver ocupada, o botão Colar próximo continua disponível. Falhas mantêm o item na fila para tentar novamente.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
