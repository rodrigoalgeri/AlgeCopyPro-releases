AlgeCopy Pro 1.3.0

Sua próxima ideia começa com uma cor. Conheça o novo Seletor de cores do AlgeCopy Pro: capture uma cor da tela, ajuste HEX, RGB, HSL e opacidade, descubra combinações e organize paletas com nome. Copie cores ou paletas como CSS e confira o contraste do texto. A nova aba Cores ocupa o lugar de Links; seus links continuam disponíveis no Histórico e na busca. As paletas ficam salvas neste computador.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
