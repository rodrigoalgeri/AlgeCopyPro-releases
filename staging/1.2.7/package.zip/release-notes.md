AlgeCopy Pro 1.2.7

Mais fluidez em cada movimento. Ajustamos o recolhimento do painel ao sair com o mouse, incluindo o uso com navegação Vim. O contorno do painel principal e da janela flutuante também foi refinado para manter os cantos contínuos e bem definidos.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
