AlgeCopy Pro 1.10.1

Corrige dobras e faixas nas bordas ao usar refração forte. A distorção passa a respeitar a largura da lente, inclusive junto às bordas da tela. Textos e ícones agora adaptam o contraste ao fundo local: escuros sobre branco e claros sobre fundos escuros, tanto no WebGL2 quanto no material nativo. Falhas transitórias de captura são isoladas por ciclo e uma nova abertura permite recuperar o efeito. Mantém os ajustes de transparência e a lógica da área de transferência.

Desenvolvido pela AlgeriTec, por Rodrigo Lampert Algeri.
https://algeritec.com.br
